package com.example.bmiapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class BMIBMRInput : AppCompatActivity() {
    lateinit var OKButton : Button
    lateinit var NOButton : Button

    lateinit var heightEditText: EditText
    lateinit var weightEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bmibmrinput)

        heightEditText = findViewById<EditText>(R.id.heightText)
        weightEditText = findViewById<EditText>(R.id.weightText)

        //버튼 인텐트 화면 전환
        OKButton = findViewById<Button>(R.id.OKbutton)

        OKButton.setOnClickListener {
            var intent = Intent(this, BMIBMRoutput::class.java)
            intent.putExtra("height", heightEditText.text.toString())
            intent.putExtra("weight", weightEditText.text.toString())
            startActivity(intent)
        }

        NOButton = findViewById<Button>(R.id.NObutton)

        NOButton.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}