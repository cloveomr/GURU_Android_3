package com.example.bmiapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    lateinit var measureButton : Button
    lateinit var sb: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // seekbar 터치 불가 코드 작성
        sb = findViewById(R.id.bmiSeekBar)
        sb.setOnTouchListener { v, event -> true }

        measureButton = findViewById<Button>(R.id.backButton)

        measureButton.setOnClickListener {
            var intent = Intent(this, BMIBMRInput::class.java)
            startActivity(intent)
        }

    }

    //menu 설정 코드
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_personnel_set, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_set -> {
                val intent = Intent(this, UserInfo::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

}
